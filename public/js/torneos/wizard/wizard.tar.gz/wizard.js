(function() {
    'use strict';

    angular
        .module('wizardTorneo', [
        	'ngAnimate',
        	'ngResource',
        	'ui.bootstrap',
        	'ngDragDrop'
        	])
        
})();